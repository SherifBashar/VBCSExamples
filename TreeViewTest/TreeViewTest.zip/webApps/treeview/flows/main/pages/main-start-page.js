define(["ojs/ojcore"], function(oj) {
  'use strict';

  var PageModule = function PageModule() {
    PageModule.prototype.populateTree = function(treeData) {
      return new oj.JsonTreeDataSource(JSON.parse(treeData));
    }
  };

  return PageModule;
});
