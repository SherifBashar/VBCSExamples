define([], function() {
  'use strict';
  var websocket = undefined;

  var AppModule = function AppModule() {
    AppModule.prototype.OpenSocket = function(arg) {
      console.log("Websocket: In open socket.");
      if (this.websocket === undefined) {
        console.log("Websocket: Starting socket listener2.");
        this.websocket = new WebSocket(
          "wss://myvbcs.oraclecloud.com/");
        this.websocket.onmessage = this.onMessage;
        this.websocket.onerror = this.onError;
        this.websocket.onclose = this.onClose;
      }
    }

    AppModule.prototype.onMessage = function(evt) {
      console.log("Websocket: On Message Called.");
      var data = JSON.parse(evt.data);
      console.log('Websocket: message :' + data.label);
      $("#oj-button--1075341696-1").click();
    }

    AppModule.prototype.onClose = function(evt) {
      console.log('websocket closed :' + evt.code + ":" + evt.reason);
      websocket = undefined;
      this.OpenSocket({}); // Reopen.
    }

    AppModule.prototype.onError = function(evt) {
      console.log('Websocket: Error :' + evt);
    }

  }

  return AppModule;

});
